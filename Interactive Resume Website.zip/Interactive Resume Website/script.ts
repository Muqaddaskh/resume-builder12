
//to make dom content fully loaded
document.addEventListener('DOMContentLoaded',function(){
  //personal information data
const form=document.getElementById("personalinfoform")as HTMLFormElement;
const firstname=document.getElementById("name")as HTMLInputElement;
const Email=document.getElementById("email")as HTMLInputElement;
const Phone=document.getElementById("phone")as HTMLInputElement;
const Address=document.getElementById("Address")as HTMLInputElement;

//education information Data
const eform=document.getElementById("education-form")as HTMLFormElement;
const schoolname=document.getElementById("sname")as HTMLInputElement;
const Degree=document.getElementById("Dname")as HTMLInputElement;
const Completionyear=document.getElementById("Yname")as HTMLInputElement;

//Skills Informatio Data
const skillform=document.getElementById("skillsform")as HTMLFormElement;
const Skills=document.getElementById("skill")as HTMLInputElement;

//Experiance information Data
const experianceform=document.getElementById("experianceform")as HTMLFormElement;
const job=document.getElementById("jobtitle")as HTMLInputElement;
const company_name=document.getElementById("company")as HTMLInputElement;
const workingexperiance=document.getElementById("yearswork")as HTMLInputElement

 
// //calling function to perform action on click

 if(form){form.addEventListener('submit',function(e){
//  //to prevent default behaviour of form

  e.preventDefault();

 //to extracting values from input fields
 const namevalue=firstname.value;
 const emailvalue=Email.value;
 const Phonevalue=Phone.value;
 const Addressvalue=Address.value;
  
  
 //to store value on localstorage

 //localstorage is used to store string data on browser

 localStorage.setItem("first-name",namevalue);
 localStorage.setItem("Email",emailvalue);
 localStorage.setItem("Phone",Phonevalue);
 localStorage.setItem("Address",Addressvalue);

 
//redirecting to the next page after submitting data

window.location.href="preview.html";
//to redirect on a education page
window.location.href="education.html"
 
 
 })}
 
 //to submit education Data on a Preview Cv Page

if(eform){{ eform.addEventListener("submit",function(e){

 
   //to prevent default behaviour of form

    e.preventDefault();

 //  //to extracting values from input fields
   const schoolvalue=schoolname.value;
   const degreevalue=Degree.value;
   const yearvalue=Completionyear.value;


 //  //to store value on localstorage
 //  //localstorage is used to store string data on browser

   localStorage.setItem("School-Name",schoolvalue);
   localStorage.setItem("Degree",degreevalue);
   localStorage.setItem("Year Of Completion",yearvalue);
 

 
  //redirecting to the next page after submitting data

  window.location.href="preview.html"
  window.location.href="skills.html"

})}}

//to submit skills data on preview cv page
if(skillform){skillform.addEventListener("submit",function (e) {
  // to prevent default page

  e.preventDefault();

  const skillvalue=Skills.value;

  //storing of skill data into local storage

  localStorage.setItem("Skills",skillvalue);

  //to redirect on new page
  window.location.href="preview.html"
  window.location.href="experiance.html"
  
})}

//to submit experiance details on previewcv page

if(experianceform){experianceform.addEventListener("submit",function(e){
  //to prevent default behaviour of html page

  e.preventDefault();

  //to get the values of experiance input elements

  const jobvalue=job.value;
  const compannyvalue=company_name.value;
  const jobyearvalue=workingexperiance.value;


  //to store values on local storage
  localStorage.setItem("Job",jobvalue);
  localStorage.setItem("Company",compannyvalue);
  localStorage.setItem("workingexp",jobyearvalue);

  //to redirect on a new page

  window.location.href="preview.html"
})}
});